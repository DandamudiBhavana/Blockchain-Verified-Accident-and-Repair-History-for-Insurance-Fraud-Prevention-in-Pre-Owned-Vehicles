# VehicleHistory — Solidity + Ganache + Remix

This is a Solidity-only educational prototype based on the uploaded vehicle accident/repair fraud-prevention use case. It includes vehicle registration, role authorization, accident and claim records, duplicate claim rejection, garage repair records, inspector verification, VIN-based history queries, and document hashes.

## 1. Start Ganache
Open Ganache and start Quickstart or open a workspace. Keep it running. The common RPC endpoint is `http://127.0.0.1:7545`.

## 2. Open Remix
Go to https://remix.ethereum.org. Create `VehicleHistory.sol` and paste the code from `contracts/VehicleHistory.sol`. In Solidity Compiler, select `0.8.20` or a compatible `0.8.x` compiler and compile.

## 3. Connect Remix to Ganache
Open Deploy & Run Transactions. Choose `Custom - External HTTP Provider` (wording may vary) and enter `http://127.0.0.1:7545`. Confirm the displayed accounts are Ganache accounts. Deploy from the first account; it becomes Admin.

## 4. Test functions from Remix's Deployed Contracts panel
Use fictional demo data only.

1. Admin: `registerVehicle("DEMO12345", "Toyota", "Corolla", 2022)`
2. Admin: `authorizeInsurer(<Ganache account address>)`
3. Admin: `authorizeGarage(<Ganache account address>)`
4. Admin: `authorizeInspector(<Ganache account address>)`
5. Switch Remix account to Insurer and call `recordAccident("DEMO12345", "CLM001", <past Unix timestamp in seconds>, "Collision", "Moderate", "Demo accident")`.
6. Switch to Garage and call `recordRepair("DEMO12345", "CLM001", <past Unix timestamp in seconds>, "Front bumper", 25000, "Completed")`.
7. Switch to Inspector and call `verifyRepair("DEMO12345", 0, true, "Repair inspected in demo")`.
8. Read history using `getVehicle`, `getAccidentByClaim`, `getAccidentCount`, `getRepairCount`, `getRepairAt`, `getInspectionCount`, and `getInspectionAt`.

Replace placeholder angle-bracket values with actual inputs; don't type the brackets. Unix timestamps must be seconds, not milliseconds, and must be in the past. Repair index is zero-based. `repairCost` is a whole-number demo amount (e.g. rupees).

## Troubleshooting
- `Unauthorized role`: select the correct Ganache account in Remix; Admin must authorize that account.
- `Vehicle not registered`: VIN must match exactly, including case.
- `Duplicate claim ID`: use a new claim ID.
- Invalid date: use a past Unix timestamp in seconds.
- Connection error: verify Ganache is running at the same RPC URL.
- Redeployment starts with fresh records and roles; register and authorize again.

## Limitations and safety
Ganache is a local development chain, not a real permissioned consortium blockchain like Hyperledger Fabric. This project demonstrates smart-contract rules only. It does not implement external oracles, real organization certificates, production privacy, or a multi-organization consensus network. Do not store real personal, insurance, or confidential information on-chain. Blockchain preserves submitted records but cannot guarantee that the original information is truthful.
